# Technical Debt / Deferred Engineering Controls — M3 starting record

| ID | Current compromise / condition | Why it matters | Next action / owner | Status |
|---|---|---|---|---|
| TD-01 | If using `EnsureCreated` rather than controlled EF migration history | Harder to upgrade schema safely | Generate/review EF migration before shared database creation; team | Open |
| TD-02 | Browserless HTTP E2E test host rather than real browser verification | JS/UI responsiveness/accessibility not fully covered | Add Playwright browser tests; testing owner | Open |
| TD-03 | Request attachments stored on one instance's disk | Multi-instance replication, antivirus scanning and disaster recovery absent | Assess secure external object storage/AV for real production; infrastructure owner | Open |
| TD-04 | Password reset/email confirmation not implemented | Production user recovery and account ownership still need verification | Add verified account recovery workflow before public launch; identity owner | Open |
| TD-05 | Event handler currently logs only | External notification is intentionally deferred; no reliable delivery queue | Retain M2 deferment; add idempotent outbox/provider if scope approved | Deferred |
| TD-06 | Overdue reporting uses provisional 7-day threshold | Not a formally agreed service SLA | Validate with stakeholders; update decision/requirements if necessary | Open |
