# M3 test evidence catalogue

**Status:** Test source exists. **Execution status: NOT VERIFIED in this delivery environment.** Run `dotnet test CivicConnect.sln --logger trx` and attach the real TRX/CI run URLs. The test titles identify scenarios; these are not fabricated pass claims.

| Test IDs | Level / technique | Requirement/risk | Expected outcome |
|---|---|---|---|
| UNIT01 | Unit, equivalence partition | FR-02 | Valid request data accepted |
| UNIT02 | Unit, equivalence partition | FR-02 | Empty/short title rejected (2 data cases) |
| UNIT03 | Unit, boundary value | FR-02 | Title length 5 accepted |
| UNIT04 | Unit, boundary value | FR-02 | Title length 121 rejected |
| UNIT05 | Unit, equivalence partition | FR-02 | Too-short description rejected |
| UNIT06 | Unit, equivalence partition | FR-02 | Missing category rejected |
| UNIT07 | Unit, equivalence partition | FR-02 | Blank location rejected |
| UNIT08 | Unit, state transition | FR-07 | Pending → InProgress allowed |
| UNIT09 | Unit, state transition | FR-07 | Pending → Closed rejected |
| UNIT10 | Unit, state transition | FR-07 | Closed has no legal transition |
| UNIT11 | Unit, state transition | FR-07 | Resolved → InProgress reopening allowed |
| UNIT12 | Unit, boundary value | FR-08 | Oversized comment rejected |
| INT01 | EF integration | FR-02 / NFR-OBS-01 | Create persists request and audit |
| INT02 | EF integration | FR-07 / NFR-OBS-01 | Status/history/audit saved as one operation |
| INT03 | EF integration, negative | FR-07, concurrency risk | Stale version rejected; no duplicate history |
| INT04 | EF integration, negative | Assignment rule | Invalid staff assignment rejected, valid accepted |
| BB01 | Black box, decision table | FR-02 / SEC | Guest redirected to login |
| BB02 | Black box, decision table | NFR-COMP-01 | Requester denied staff queue |
| BB03 | Black box, negative / ownership | NFR-COMP-01 | Another requester's details denied |
| BB04 | Black box, equivalence partition | FR-02 | Invalid title rejected at HTTP boundary |
| BB05 | Black box, equivalence partition | FR-02 | Unknown category rejected without DB writes |
| SEC01 | Security integration | NFR-SEC-01 | Stored password hash, never plaintext |
| SEC02 | Security black box, negative | NFR-SEC-02 supporting hardening | POST without CSRF token rejected |
| SEC03 | Security black box, negative | FR-07 / NFR-COMP-01 | Requester denied staff status changes |
| E2E01 | Web HTTP system flow | FR-01/02/04 | Authenticated requester submits and sees Pending |
| E2E02 | Web HTTP system flow | FR-05/07/04 | Staff changes status; requester sees history |
| PERF01 | k6, separate workload | NFR-PERF-01 | Measure authenticated dashboard p95/error rate |

> The two `E2E` cases use the entire MVC + Identity + application + EF + test-database flow via HTTP, but **not a real browser UI engine**. The team should add a browser Playwright smoke check if full-browser evidence is desired. This limitation must be stated honestly in the PED.

## Required M3 coverage and interpretation

- At least 5 unit/component tests: UNIT01–12.
- At least 5 black-box functional tests: BB01–05 (plus SEC02/03).
- At least 3 API/integration tests: INT01–04.
- At least 2 E2E/system tests: E2E01–02.
- At least 3 negative/failure/unauthorised tests: UNIT09, INT03, BB02/03/04/05, SEC02/03.
- At least 5 high-priority requirement/risk cases: INT01–03, BB02–03, SEC01–03, E2E01–02.
- At least 2 suitable black-box design techniques: **equivalence partitioning** and **decision table** (also BVA and state transition at unit level).
- Separate manageable performance scenario: PERF01. Before running, record host, dataset size, number of VUs, duration, p95 and errors; do not infer 1,000/5,000-user compliance from a 5-user test.

## For each executed test record

Test ID → requirement or risk → input/preconditions → expected result → observed result → pass/fail/blocked → CI/TRX evidence URL → limitation or defect ID. Fill actual results only after running the tests.
