# M3 Defect Register — initialise when real defects are discovered

| Defect ID | Requirement/test | Description & reproduction | Severity | Status | PR/fix | Regression run/evidence |
|---|---|---|---|---|---|---|
| _Pending_ | — | Record genuine observed defects after testing | — | Not evaluated | — | — |

Do not invent defects for mark allocation. Each discovered fault should have the responsible owner, impact, evidence and a regression check if fixed.
