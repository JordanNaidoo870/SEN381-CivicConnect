# Development / database control

- Use .NET 10 SDK and Visual Studio 2026 (18.0+), PostgreSQL 18, Git and a current browser.
- Configure `ConnectionStrings:CivicConnect`, `SeedAdmin:Email` and `SeedAdmin:Password` via .NET user-secrets locally or environment variables in staging; never commit real values.
- Local startup initialises the database (`EnsureCreated` if **no migrations exist**) and seeds required roles/categories.
- **For proper change control**, generate the initial migration via `tools/create-migrations.ps1` against an empty development database **before** running the application for the first time; commit reviewed migration files through a PR.
- Do not apply migrations to an `EnsureCreated` database, because it has no EF migration history. Use a fresh migrated database or controlled export/import.
- Tests use isolated disposable SQLite; exercise true PostgreSQL behavior separately before release claims.
- No M2 architecture changes should be made silently: record important changes in an ADR or change request and update RTM, risks and the same PED.
- Database transaction protects status + history + audit. Request creation, assignment, comments and attachments create audit entries. Detail reads are also audited.
- Sensitive attachments are stored outside `wwwroot` and downloaded through authenticated/authorised MVC actions. Virus scanning and external encrypted object storage remain future controls for a real production release.
- Do not copy credentials into screenshots, build logs, PR descriptions or commits.
