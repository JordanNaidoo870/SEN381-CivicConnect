# Continuation instructions for the existing M1/M2 RTM

Do not replace or recreate the existing requirements baseline. Update the actual RTM in PED v2.0 or its controlled source so it becomes the M3 live matrix. Where applicable, link to these code/test IDs:

| Requirement | Implementation | Planned test evidence to link after actual execution | Status |
|---|---|---|---|
| FR-01 | `AccountController`, ASP.NET Core Identity | E2E01, SEC01 | Code authored; tests unverified |
| FR-02 | `RequestsController.Create`, `RequestService`, EF repository | UNIT01–07, BB04–05, INT01, E2E01 | Code authored; tests unverified |
| FR-03 | `RequestsController.Upload/Download`, RequestAttachment | Manual file-format/authorisation tests still needed | Code authored; test gap |
| FR-04 | `RequestsController.Index/Details` | BB03, E2E01/02 | Code authored; tests unverified |
| FR-05 | `StaffController.Queue` | BB02, E2E02 | Code authored; tests unverified |
| FR-06 | staff filtered/paged listing | Test category/status/date boundary combinations | Code authored; test gap |
| FR-07 | status service, domain transition, EF transaction | UNIT08–11, INT02/03, SEC03, E2E02 | Code authored; tests unverified |
| FR-08 | `RequestsController.AddComment` | UNIT12 plus additional authorization flow test | Code authored; test gap |
| NFR-SEC-01 | Identity password hasher | SEC01 | Code authored; tests unverified |
| NFR-SEC-02 | HTTPS middleware / production secure-cookie setting | Production TLS 1.2+ inspection still needed | Not fully verified |
| NFR-COMP-01 | Role and request-ownership checks | BB02/03, SEC03, privacy review outstanding | Not fully verified |
| NFR-OBS-01 | AuditLog / transactional persistence | INT01/02 | Code authored; tests unverified |
| NFR-PERF-01 | paginated list + indexes | PERF01, expected 1000-user acceptance not yet tested | Not verified |
| NFR-SCALE-01 | stateless request stack; database indexes | 5000-session workload not tested | Not verified |
| NFR-REL-01 | single app + DB; staging only | Business-hours uptime monitoring not tested | Not verified |
| NFR-COST-01 | single app/deployment direction | Provider estimate/monthly bill pending | Not verified |

The RTM must hold **actual commit/class path, test report/CI run link, status and defect ID** once implementation is merged and tested.
