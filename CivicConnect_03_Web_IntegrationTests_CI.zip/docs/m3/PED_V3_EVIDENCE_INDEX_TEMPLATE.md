# Insert into the existing PED when evolving PED v2.0 → v3.0

**This file is a template, not a separate milestone report.** Preserve v1.0/v2.0 history and current ADRs, stakeholders, constraints and traceability.

## Submission information block (fill with actual evidence)

Team: CivicConnect — Jordan Naidoo (602463), Tshepo Koithen (603233), Darrin Everette Mokuena (601172)
GitHub URL: [ACTUAL CONTROLLED REPOSITORY URL]
M3 release commit/tag: [ACTUAL IMMUTABLE IDENTIFIER]
PED version: v3.0
RTM location: [LINK]
CI/test result run URL: [LINK]
Staging URL or reproducible demo instructions: [LINK/INSTRUCTIONS]
Submitted date: [DATE]

## M3 sections to add to same PED

1. M3 overview, agreed scope, release ID, implemented status.
2. M2 conformance, real source paths and significant deviations/approved change records.
3. Controlled construction, three-person PR reviews and environment configuration.
4. CI build/test/static/security/dependency checks, blocking gates and actual run links.
5. Risk-based quality plan, 15+ meaningful tests, black-box techniques, critical failures and outcomes.
6. Integration/E2E and acceptance evidence, link to RTM and observed results.
7. Small performance exercise including duration/VUs/environment/p95/error rate/limitations.
8. Separate staging/test deployment, exact candidate revision, verification and rollback/recovery.
9. Defects and regression, technical debt, updated risk register/ADRs.
10. Release Evidence Summary: actual READY / CONDITIONALLY READY / NOT READY with reasons and residual risk owners.

Never state that tests passed or a staging release exists unless an actual run/deployment has been completed and captured.
