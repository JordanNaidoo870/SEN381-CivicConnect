## Summary / related issue
Closes #

## Requirement or engineering rationale
Requirement ID:
ADR / risk:

## Evidence
- [ ] Locally builds
- [ ] Relevant tests run and evidence linked
- [ ] No secrets committed
- [ ] Security, permissions and data effects reviewed
- [ ] PED/RTM/README updated where appropriate

## Reviewer notes
Two independent reviews required for substantive changes entering protected main.
